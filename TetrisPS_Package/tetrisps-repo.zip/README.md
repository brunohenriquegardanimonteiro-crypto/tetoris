﻿Tetris PS - Tetris clássico (estilo 1984) em PowerShell

Como rodar:
- PowerShell: .\tetris.ps1
- PowerShell 7 (pwsh): pwsh -NoProfile .\tetris.ps1
- CMD: powershell -NoProfile -ExecutionPolicy Bypass -File .\tetris.ps1

Controles:
- ← →: mover
- ↓: acelerar queda
- ↑ / Espaço: rotacionar
- Q/Escape: sair

Música: Korobeiniki (remix 8-bit). Usado em memória se possível (sem gravar arquivo desnecessário).
